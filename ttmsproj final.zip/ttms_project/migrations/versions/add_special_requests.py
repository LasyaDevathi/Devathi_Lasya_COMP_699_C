"""Add special_requests to Booking model

Revision ID: add_special_requests_column
Create Date: 2025-04-29 14:45:00
"""

from alembic import op
import sqlalchemy as sa

# revision identifiers
revision = 'add_special_requests_column'
# Set this to the last successful migration in your history
down_revision = '55ee7cef7e40'  # This should be the ID of your most recent successful migration
branch_labels = None
depends_on = None

def upgrade():
    # Add the special_requests column to the bookings table
    with op.batch_alter_table('bookings', schema=None) as batch_op:
        batch_op.add_column(sa.Column('special_requests', sa.Text(), nullable=True))

def downgrade():
    # Remove the special_requests column if we need to roll back
    with op.batch_alter_table('bookings', schema=None) as batch_op:
        batch_op.drop_column('special_requests')