from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, IntegerField, DateField, SelectField, SubmitField
from wtforms.validators import DataRequired, Length, NumberRange, Optional, ValidationError
from datetime import datetime

class BookingForm(FlaskForm):
    """Form for creating a booking."""
    start_date = DateField('Check-in Date', validators=[DataRequired()])
    end_date = DateField('Check-out Date', validators=[DataRequired()])
    num_guests = IntegerField('Number of Guests', validators=[DataRequired(), NumberRange(min=1)])
    special_requests = TextAreaField('Special Requests', validators=[Optional(), Length(max=500)])
    submit = SubmitField('Proceed to Payment')
    
    def validate_start_date(self, field):
        if field.data < datetime.now().date():
            raise ValidationError('Check-in date cannot be in the past.')
    
    def validate_end_date(self, field):
        if field.data <= self.start_date.data:
            raise ValidationError('Check-out date must be after check-in date.')

class PaymentForm(FlaskForm):
    """Form for processing payments."""
    payment_method = SelectField('Payment Method', choices=[
        ('CREDIT_CARD', 'Credit Card'),
        ('DEBIT_CARD', 'Debit Card'),
        ('PAYPAL', 'PayPal')
    ], validators=[DataRequired()])
    
    cardholder_name = StringField('Cardholder Name', validators=[Optional(), Length(min=3, max=128)])
    card_number = StringField('Card Number', validators=[Optional(), Length(min=13, max=19)])
    expiry_month = SelectField('Expiry Month', choices=[(str(i), str(i)) for i in range(1, 13)], validators=[Optional()])
    expiry_year = SelectField('Expiry Year', choices=[(str(i), str(i)) for i in range(datetime.now().year, datetime.now().year + 11)], validators=[Optional()])
    cvv = StringField('CVV', validators=[Optional(), Length(min=3, max=4)])
    
    submit = SubmitField('Complete Payment')
    
    def validate(self):
        """Custom validation to require card fields only when payment method is card-based."""
        if not super(PaymentForm, self).validate():
            return False
            
        # Only validate card details for card payments
        if self.payment_method.data in ['CREDIT_CARD', 'DEBIT_CARD']:
            if not self.cardholder_name.data:
                self.cardholder_name.errors.append('Cardholder name is required for card payments')
                return False
                
            if not self.card_number.data:
                self.card_number.errors.append('Card number is required for card payments')
                return False
                
            if not self.cvv.data:
                self.cvv.errors.append('CVV is required for card payments')
                return False
        
        return True