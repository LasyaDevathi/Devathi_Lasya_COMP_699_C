from flask import Blueprint

main = Blueprint('main', __name__)

from . import routes
from . import notification_routes  # Add this line
from . import profile_routes      # Add this line