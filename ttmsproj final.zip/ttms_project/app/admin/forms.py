from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, IntegerField, FloatField, BooleanField, SelectField, SubmitField
from wtforms.validators import DataRequired, Length, NumberRange, Optional, URL

class PackageForm(FlaskForm):
    """Form for creating and editing travel packages."""
    name = StringField('Package Name', validators=[DataRequired(), Length(min=3, max=128)])
    description = TextAreaField('Description', validators=[DataRequired()])
    destination = StringField('Destination', validators=[DataRequired(), Length(min=2, max=128)])
    duration_days = IntegerField('Duration (Days)', validators=[DataRequired(), NumberRange(min=1, max=30)])
    price_per_day = FloatField('Price Per Day ($)', validators=[DataRequired(), NumberRange(min=10)])
    max_guests = IntegerField('Maximum Guests', validators=[DataRequired(), NumberRange(min=1, max=50)])
    is_available = BooleanField('Available for Booking')
    image_url = StringField('Image URL', validators=[Optional(), URL()])
    submit = SubmitField('Save Package')

class UserRoleForm(FlaskForm):
    """Form for updating user roles."""
    role = SelectField('Role', validators=[DataRequired()], coerce=int)
    submit = SubmitField('Update Role')
    
    def __init__(self, *args, **kwargs):
        super(UserRoleForm, self).__init__(*args, **kwargs)
        from app.models import Role
        self.role.choices = [(role.id, role.name) for role in Role.query.all()]

class BookingStatusForm(FlaskForm):
    """Form for updating booking status."""
    status = SelectField('Status', choices=[
        ('PENDING_PAYMENT', 'Pending Payment'),
        ('CONFIRMED', 'Confirmed'),
        ('CANCELLED', 'Cancelled'),
        ('COMPLETED', 'Completed')
    ], validators=[DataRequired()])
    submit = SubmitField('Update Status')