from flask import render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user
from app import db
from app.admin import admin
from app.models import User, TravelPackage, Booking, Review, Role, Itinerary, Payment
from app.admin.forms import PackageForm, UserRoleForm, BookingStatusForm
from sqlalchemy import func
from datetime import datetime, timedelta

def admin_required(func):
    """Decorator to check if user has admin role."""
    @login_required
    def decorated_view(*args, **kwargs):
        if not current_user.role or current_user.role.name != 'Admin':
            abort(403)
        return func(*args, **kwargs)
    decorated_view.__name__ = func.__name__
    return decorated_view


@admin.route('/')
@admin_required
def index():
    """Admin dashboard with statistics and quick actions."""
    # Get counts for dashboard stats
    user_count = User.query.count()
    package_count = TravelPackage.query.count()
    booking_count = Booking.query.count()
    review_count = Review.query.count()
    
    # Get recent bookings
    recent_bookings = Booking.query.order_by(Booking.created_at.desc()).limit(10).all()
    
    # Get revenue stats
    total_revenue = db.session.query(func.sum(Booking.total_price))\
        .filter(Booking.status.in_(['CONFIRMED', 'COMPLETED']))\
        .scalar() or 0
    
    # Monthly revenue (last 30 days)
    month_ago = datetime.now() - timedelta(days=30)
    monthly_revenue = db.session.query(func.sum(Booking.total_price))\
        .filter(Booking.status.in_(['CONFIRMED', 'COMPLETED']))\
        .filter(Booking.created_at >= month_ago)\
        .scalar() or 0
    
    # Get pending bookings that need attention
    pending_bookings = Booking.query.filter_by(status='PENDING_PAYMENT').count()
    
    return render_template('admin/index.html',
                          title='Admin Dashboard',
                          stats={
                              'users': user_count,
                              'packages': package_count,
                              'bookings': booking_count,
                              'reviews': review_count,
                              'total_revenue': total_revenue,
                              'monthly_revenue': monthly_revenue,
                              'pending_bookings': pending_bookings
                          },
                          recent_bookings=recent_bookings)


@admin.route('/users')
@admin_required
def users():
    """List all users with filtering and pagination."""
    page = request.args.get('page', 1, type=int)
    role_filter = request.args.get('role', None, type=int)
    search = request.args.get('search', '')
    
    # Build query with optional filters
    query = User.query
    
    if role_filter:
        query = query.filter(User.role_id == role_filter)
    
    if search:
        search_term = f"%{search}%"
        query = query.filter(
            (User.username.ilike(search_term)) | 
            (User.email.ilike(search_term)) |
            (User.first_name.ilike(search_term)) |
            (User.last_name.ilike(search_term))
        )
    
    users = query.order_by(User.created_at.desc()).paginate(page=page, per_page=20)
    roles = Role.query.all()
    
    return render_template('admin/users.html',
                          title='User Management',
                          users=users,
                          roles=roles,
                          role_filter=role_filter,
                          search=search)


@admin.route('/user/<int:user_id>', methods=['GET', 'POST'])
@admin_required
def user_detail(user_id):
    """View and edit user details including role assignment."""
    user = User.query.get_or_404(user_id)
    form = UserRoleForm()
    
    if form.validate_on_submit():
        user.role_id = form.role.data
        db.session.commit()
        flash(f'Role updated for {user.username}', 'success')
        return redirect(url_for('admin.user_detail', user_id=user_id))
    
    if request.method == 'GET':
        form.role.data = user.role_id
    
    # Get user's bookings and activity
    bookings = Booking.query.filter_by(user_id=user_id).order_by(Booking.created_at.desc()).limit(5).all()
    reviews = Review.query.filter_by(user_id=user_id).order_by(Review.created_at.desc()).limit(5).all()
    
    return render_template('admin/user_detail.html',
                          title=f'User: {user.username}',
                          user=user,
                          form=form,
                          bookings=bookings,
                          reviews=reviews)


@admin.route('/packages')
@admin_required
def packages():
    """List all travel packages with filtering and search."""
    page = request.args.get('page', 1, type=int)
    available_only = request.args.get('available', None, type=int)
    search = request.args.get('search', '')
    
    # Build query with optional filters
    query = TravelPackage.query
    
    if available_only:
        query = query.filter_by(is_available=True)
    
    if search:
        search_term = f"%{search}%"
        query = query.filter(
            (TravelPackage.name.ilike(search_term)) | 
            (TravelPackage.destination.ilike(search_term)) |
            (TravelPackage.description.ilike(search_term))
        )
    
    packages = query.order_by(TravelPackage.created_at.desc()).paginate(page=page, per_page=10)
    
    return render_template('admin/packages.html',
                          title='Travel Packages',
                          packages=packages,
                          available_only=available_only,
                          search=search)


@admin.route('/package/new', methods=['GET', 'POST'])
@admin_required
def new_package():
    """Create a new travel package."""
    form = PackageForm()
    
    if form.validate_on_submit():
        package = TravelPackage(
            name=form.name.data,
            description=form.description.data,
            destination=form.destination.data,
            duration_days=form.duration_days.data,
            price_per_day=form.price_per_day.data,
            max_guests=form.max_guests.data,
            is_available=form.is_available.data,
            image_url=form.image_url.data or None
        )
        
        db.session.add(package)
        db.session.commit()
        
        flash('Travel package created successfully!', 'success')
        return redirect(url_for('admin.packages'))
    
    return render_template('admin/package_form.html',
                          title='New Travel Package',
                          form=form)


@admin.route('/package/edit/<int:package_id>', methods=['GET', 'POST'])
@admin_required
def edit_package(package_id):
    """Edit an existing travel package."""
    package = TravelPackage.query.get_or_404(package_id)
    form = PackageForm()
    
    if form.validate_on_submit():
        package.name = form.name.data
        package.description = form.description.data
        package.destination = form.destination.data
        package.duration_days = form.duration_days.data
        package.price_per_day = form.price_per_day.data
        package.max_guests = form.max_guests.data
        package.is_available = form.is_available.data
        package.image_url = form.image_url.data or None
        
        db.session.commit()
        
        flash('Travel package updated successfully!', 'success')
        return redirect(url_for('admin.packages'))
    
    if request.method == 'GET':
        form.name.data = package.name
        form.description.data = package.description
        form.destination.data = package.destination
        form.duration_days.data = package.duration_days
        form.price_per_day.data = package.price_per_day
        form.max_guests.data = package.max_guests
        form.is_available.data = package.is_available
        form.image_url.data = package.image_url
    
    return render_template('admin/package_form.html',
                          title='Edit Travel Package',
                          form=form,
                          package=package)


@admin.route('/bookings')
@admin_required
def bookings():
    """List all bookings with filtering options."""
    page = request.args.get('page', 1, type=int)
    status_filter = request.args.get('status', None)
    search = request.args.get('search', '')
    date_from = request.args.get('date_from', None)
    date_to = request.args.get('date_to', None)
    
    # Build query with optional filters
    query = Booking.query
    
    if status_filter:
        query = query.filter_by(status=status_filter)
    
    if search:
        # Join with users and packages for searching
        query = query.join(User).join(TravelPackage)
        search_term = f"%{search}%"
        query = query.filter(
            (User.username.ilike(search_term)) | 
            (User.email.ilike(search_term)) |
            (TravelPackage.name.ilike(search_term))
        )
    
    if date_from:
        try:
            date_from = datetime.strptime(date_from, '%Y-%m-%d').date()
            query = query.filter(Booking.start_date >= date_from)
        except ValueError:
            pass
    
    if date_to:
        try:
            date_to = datetime.strptime(date_to, '%Y-%m-%d').date()
            query = query.filter(Booking.end_date <= date_to)
        except ValueError:
            pass
    
    # Get paginated bookings ordered by creation date (newest first)
    bookings = query.order_by(Booking.created_at.desc()).paginate(page=page, per_page=20)
    
    return render_template('admin/bookings.html',
                          title='Booking Management',
                          bookings=bookings,
                          status_filter=status_filter,
                          search=search,
                          date_from=date_from,
                          date_to=date_to)

@admin.route('/booking/update/<int:booking_id>', methods=['POST'])
@admin_required
def update_booking(booking_id):
    """Update booking status."""
    booking = Booking.query.get_or_404(booking_id)
    
    # Update status from form data
    new_status = request.form.get('status')
    if new_status in ['PENDING_PAYMENT', 'CONFIRMED', 'CANCELLED', 'COMPLETED']:
        booking.status = new_status
        db.session.commit()
        flash('Booking status updated successfully!', 'success')
    else:
        flash('Invalid booking status.', 'danger')
    
    return redirect(url_for('admin.booking_detail', booking_id=booking_id))
@admin.route('/booking/<int:booking_id>', methods=['GET', 'POST'])
@admin_required
def booking_detail(booking_id):
    """View booking details and update status."""
    booking = Booking.query.get_or_404(booking_id)
    form = BookingStatusForm()
    
    if form.validate_on_submit():
        booking.status = form.status.data
        db.session.commit()
        flash('Booking status updated successfully!', 'success')
        return redirect(url_for('admin.booking_detail', booking_id=booking_id))
    
    if request.method == 'GET':
        form.status.data = booking.status
    
    user = User.query.get(booking.user_id)
    package = TravelPackage.query.get(booking.package_id)
    payments = Payment.query.filter_by(booking_id=booking_id).all()
    
    return render_template('admin/booking_detail.html',
                          title='Booking Details',
                          booking=booking,
                          user=user,
                          package=package,
                          payments=payments,
                          form=form)