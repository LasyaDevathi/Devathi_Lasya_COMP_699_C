from app import create_app, db
from app.models import User, Role, TravelPackage, Booking, Payment, Notification
from datetime import datetime, timedelta
import random

def seed_bookings_with_special_requests():
    """Add sample bookings with special requests."""
    app = create_app('development')
    
    with app.app_context():
        # Get travelers and packages
        traveler_role = Role.query.filter_by(name='Traveler').first()
        travelers = User.query.filter_by(role_id=traveler_role.id).all()
        packages = TravelPackage.query.all()
        
        if not travelers or not packages:
            print("No travelers or packages found. Please run the basic seed script first.")
            return
        
        # Sample special requests
        special_requests_options = [
            "I would like to arrange a birthday surprise for my partner during the trip.",
            "We have dietary restrictions: one vegetarian and one gluten-free.",
            "We prefer a room on a higher floor with a good view if possible.",
            "We will be arriving late on the first day, around 11 PM.",
            "Could we have adjoining rooms for our family?",
            "I would appreciate recommendations for local vegetarian restaurants.",
            "We need a crib in the room for our 6-month-old baby.",
            "I use a wheelchair and would need accessible accommodations.",
            "We would like to book a private tour guide for one day.",
            None  # Some bookings with no special requests
        ]
        
        # Create sample bookings
        for traveler in travelers:
            for _ in range(2):  # Create 2 bookings per traveler
                package = random.choice(packages)
                
                # Generate future date for booking
                start_date = datetime.now() + timedelta(days=random.randint(30, 180))
                start_date = start_date.date()
                end_date = start_date + timedelta(days=package.duration_days)
                
                num_guests = random.randint(1, min(4, package.max_guests))
                total_price = package.price_per_day * package.duration_days * num_guests
                special_requests = random.choice(special_requests_options)
                
                # Check if booking already exists
                existing_booking = Booking.query.filter_by(
                    user_id=traveler.id,
                    package_id=package.id,
                    start_date=start_date
                ).first()
                
                if not existing_booking:
                    # Create new booking with special requests
                    booking = Booking(
                        user_id=traveler.id,
                        package_id=package.id,
                        start_date=start_date,
                        end_date=end_date,
                        num_guests=num_guests,
                        total_price=total_price,
                        status='CONFIRMED',
                        special_requests=special_requests
                    )
                    
                    db.session.add(booking)
                    
                    # Create a payment record
                    payment = Payment(
                        booking_id=booking.id,
                        amount=total_price,
                        method='CREDIT_CARD',
                        status='COMPLETED',
                        transaction_id=f'SIMULATED-{datetime.now().strftime("%Y%m%d%H%M%S")}'
                    )
                    
                    db.session.add(payment)
                    
                    # Create notification for booking
                    notification = Notification(
                        user_id=traveler.id,
                        title='Booking Confirmed',
                        message=f'Your booking for {package.name} is confirmed.',
                        type='BOOKING_CONFIRMATION',
                        is_read=False
                    )
                    
                    db.session.add(notification)
                else:
                    # Update existing booking with special requests if it doesn't have one
                    if not existing_booking.special_requests:
                        existing_booking.special_requests = special_requests
        
        db.session.commit()
        print("Sample bookings with special requests added successfully!")

if __name__ == '__main__':
    seed_bookings_with_special_requests()